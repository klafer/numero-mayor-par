-----------2 de junio del 2017-------------

//--------------------------------------------------------------------------------------------------------

Proyecto: Venta de Mascotas

Permite a los usuarios registrados como vendedores el poder publicar mascotas para que otras personas interesadas en ellas puedan contactarlo, ya sea por medio de telefono o Email.

A los usuarios registrados como compradores, solo se les permite ver las mascotas disponibles, y los datos necesarios para poder contactar a los vendedores

Los usuarios no registrados solo pueden ver las mascotas que se encuentran disponibles

//--------------------------------------------------------------------------------------------------------

Para realizar los siguientes pasos, se da por hecho que ya se cuentan con servidor apache, ademas de los servicios de mysql, php, etc.

En phpmyadmin se crea una base de datos llamada "venta_mascotas", entramos a la base de datos e importamos el archivo .sql que tenemos.

Movemos la carpeta de nuestro proyecto a la direccion var/www/html/

Entramos a la carpeta de nuestro proyecto ahi abrimos el archivo index y editamos los valores para poder realizar la conexion a la base de datos

En el archivo index de la carpeta slimphp, podemos ver las rutas GET que tenemos disponibles.

localhost/venta_mascotas/ContactoVendedor
localhost/venta_mascotas/Mascotas
localhost/venta_mascotas/TipoMascotas

**Las rutas post no las podemos utilizar en el navegador, ya que no hay un formulario para enviar la informaci�n**
//----------------------------------------------------------------------------------------------------------

En caso de no haber modificado antes el archivo apache2.conf , debemos entrar a cambiar lo siguiente, para obtener los permisos necesarios para entrar a las rutas sin problemas.

Reemplazar "AllowOverride None" por "AllowOverride All"

<Directory /usr/share>
AllowOverride all
Require all granted
</Directory>

guardamos y reiniciamos el servicio de apache2