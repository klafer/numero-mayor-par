-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 01-06-2017 a las 23:23:22
-- Versión del servidor: 5.5.55-0ubuntu0.14.04.1
-- Versión de PHP: 5.5.9-1ubuntu4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `venta_mascotas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mascota`
--

CREATE TABLE IF NOT EXISTS `mascota` (
  `IdMascota` int(11) NOT NULL AUTO_INCREMENT,
  `IdTipoMascota` int(11) NOT NULL,
  `IdUsuario` int(11) NOT NULL,
  `RazaMascota` varchar(25) NOT NULL,
  `Edad` varchar(20) NOT NULL,
  `Precio` decimal(11,2) NOT NULL,
  `Caracteristicas` varchar(400) DEFAULT NULL,
  `Imagen` varchar(70) NOT NULL,
  PRIMARY KEY (`IdMascota`),
  KEY `fk_TipoMascota_idx` (`IdTipoMascota`),
  KEY `fk_IdVendedor_idx` (`IdUsuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `mascota`
--

INSERT INTO `mascota` (`IdMascota`, `IdTipoMascota`, `IdUsuario`, `RazaMascota`, `Edad`, `Precio`, `Caracteristicas`, `Imagen`) VALUES
(1, 1, 1, 'Husky', '2 meses', 2000.00, 'Ojos Azules, Pelo blanco con gris', 'ruta de la imagen'),
(2, 1, 1, 'Pitbull', '1 mes', 1500.00, 'Perro color cafe, ojos azules', 'Ruta de la imagen'),
(3, 1, 1, 'Pug', '2 semanas', 1300.00, 'Perro de color gris', 'Ruta de la imagen'),
(4, 2, 1, 'Persa', '2 semanas', 1600.00, 'Gato de color gris, con ojos color verde', 'Ruta de la imagen'),
(5, 2, 1, 'SiamÃ¨s', '1 semana', 1300.00, 'Gato de color gris', 'Ruta de la imagen');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipomascota`
--

CREATE TABLE IF NOT EXISTS `tipomascota` (
  `IdTipoMascota` int(11) NOT NULL AUTO_INCREMENT,
  `NombreTipo` varchar(15) NOT NULL,
  PRIMARY KEY (`IdTipoMascota`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `tipomascota`
--

INSERT INTO `tipomascota` (`IdTipoMascota`, `NombreTipo`) VALUES
(1, 'Perro'),
(2, 'Gato');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `IdUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `TipoUsuario` varchar(20) NOT NULL,
  `Nombre` varchar(35) NOT NULL,
  `Apellidos` varchar(45) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(35) NOT NULL,
  `Telefono` int(15) DEFAULT NULL,
  `Estado` varchar(45) NOT NULL,
  `Ciudad` varchar(45) NOT NULL,
  `Direccion` varchar(180) DEFAULT NULL,
  PRIMARY KEY (`IdUsuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`IdUsuario`, `TipoUsuario`, `Nombre`, `Apellidos`, `Email`, `Password`, `Telefono`, `Estado`, `Ciudad`, `Direccion`) VALUES
(1, 'Vendedor', 'Hugo', 'Ruiz', 'hugoruiz@hotmail.com', 'hugo', 123456, 'Baja California', 'Ensenada', 'Villa Colonial'),
(2, 'Comprador', 'Victor', 'Flores', 'Victor@mail', '123', 123, 'Baja', 'Ens', 'Villa'),
(3, 'Vendedor', 'Pancho', 'Villa', 'Pancho@mail.com', '1234', 4321, 'Baja', 'Tijuana', 'Calle Tijuana #3'),
(4, 'Comprador', 'Java', 'Script', 'Script@mail.com', '1234', 4321, 'Baja', 'Tijuana', 'Calle Tijuana #3');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `mascota`
--
ALTER TABLE `mascota`
  ADD CONSTRAINT `fk_IdTipoMascota` FOREIGN KEY (`IdTipoMascota`) REFERENCES `tipomascota` (`IdTipoMascota`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_IdUsuario` FOREIGN KEY (`IdUsuario`) REFERENCES `usuario` (`IdUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
